/**
  ******************************************************************************
  * @file usart.h 
  * @author  LISTEN Application Team
  * @version  V1.0.0
  * @date  09/10/2009
  * @brief  Header for usart.c file.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 LISTEN</center></h2>
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

/* Includes ------------------------------------------------------------------*/
#include "includew.h"
#include "UpdataProg.h"
#include "modbus.h"
#include "protocol.h"

/* Exported types ------------------------------------------------------------*/
//����ͨѶ���ƿ�
typedef struct 				
{	
	unsigned char	CommStatus;		//ͨѶ״̬
	unsigned short	RxdByteCnt;		//�����ֽڼ���
	unsigned short	TxdPackLength;	//���Ͱ�����
}STM_USART_CtrolBlock;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/
#define DELAY_TIME_OUT1 0xfffff
//

#define USART1_IRQChannel            ((INT8U)0x25)  /* USART1 global Interrupt */
#define USART2_IRQChannel            ((INT8U)0x26)  /* USART2 global Interrupt */
//

#define USART_SPACE_PARITY USART_Parity_Even
#define USART_MARK_PARITY  USART_Parity_Odd
#define USART_NONE_PARITY  USART_Parity_No

#define USART485 0x01
#define USART232 0x00
#define USART_MARK 0xE9FF

#define USART232_ClearRecvIT          USART_ClearITPendingBit(USART1,USART_IT_RXNE);
#define USART232_RecvITByte( data )   data = (USART1->DR & (INT16U)0x01FF)
#define USART232_RecvByte( data )     USART1->SR &= (INT16U)(~(USART_FLAG_RXNE)); data = USART1->DR
#define USART232_WaitData()           ((USART1->SR & USART_FLAG_RXNE) ? FALSE : TRUE)
#define USART232_ENABLE_RXNE          *(INT32U*)( 0x4001380C ) |= 0x00000020
#define USART232_DISABLE_RXNE         *(INT32U*)( 0x4001380C ) &= ~0x00000020
#define USART232_GetRecvIT()          (  USART_GetITStatus(USART1, USART_IT_RXNE) ? TRUE : FALSE)

#define USART232_SpaceParity        USART1->CR1 = (USART1->CR1 & (USART_MARK)) |  USART_WordLength_9b | USART_StopBits_1 | USART_SPACE_PARITY  
#define USART232_MarkParity         USART1->CR1 = (USART1->CR1 & (USART_MARK)) |  USART_WordLength_9b | USART_StopBits_1 | USART_MARK_PARITY 
#define USART232_NoneParity         USART1->CR1 = (USART1->CR1 & (USART_MARK)) |  USART_WordLength_8b | USART_StopBits_1 | USART_NONE_PARITY

#define USART485_ClearRecvIT          USART_ClearITPendingBit(USART2,USART_IT_RXNE);
#define USART485_RecvITByte( data )   data = (USART2->DR & (INT16U)0x01FF)//USART_ReceiveData(USART2)
#define USART485_RecvByte( data )     USART2->SR &= (INT16U)(~(USART_FLAG_RXNE)); data = USART2->DR//USART_ClearFlag(USART2,USART_FLAG_RXNE); data = USART_ReceiveData(USART2)
#define USART485_WaitData()           ((USART2->SR & USART_FLAG_RXNE) ? FALSE : TRUE)//( USART_GetFlagStatus(USART2, USART_FLAG_RXNE) ? FALSE : TRUE )
#define USART485_ENABLE_RXNE          *(INT32U*)( 0x4000440C ) |= 0x00000020
#define USART485_DISABLE_RXNE         *(INT32U*)( 0x4000440C ) &= ~0x00000020
#define USART485_GetRecvIT()          (  USART_GetITStatus(USART2, USART_IT_RXNE) ? TRUE : FALSE)


#define USART485_SpaceParity        USART2->CR1 = (USART2->CR1 & (USART_MARK)) |  USART_WordLength_9b | USART_StopBits_1 | USART_SPACE_PARITY 
#define USART485_MarkParity         USART2->CR1 = (USART2->CR1 & (USART_MARK)) |  USART_WordLength_9b | USART_StopBits_1 | USART_MARK_PARITY  
#define USART485_NoneParity         USART2->CR1 = (USART2->CR1 & (USART_MARK)) |  USART_WordLength_8b | USART_StopBits_1 | USART_NONE_PARITY  

// RS485 ͨѶ�ӿڶ���
#define RS485CS                    GPIO_Pin_11   
#define RS_CTRL_LINE               GPIOC
//
//#define Rs485S  GPIOC->BRR = 1<<11//GPIO_SET( RS_CTRL_LINE , RS485CS)
//#define Rs485R  GPIOC->BSRR = 1<<11//GPIO_RESET( RS_CTRL_LINE , RS485CS)
#define Rs485S GPIOC->BRR = 1<<11
#define Rs485R GPIOC->BSRR = 1<<11

//uart dma
#define	COMM_IDLE		0x00
#define	TXD_BEG			(1<<0)
#define	TXD_ING			(1<<1)
#define	TXD_SPACE		(1<<2)
#define	TXD_ENABLE		(1<<3)
#define	RXD_WAIT		(1<<4)
#define	RXD_ING			(1<<5)
#define	RXD_END			(1<<6)
#define	RXD_TIME_OVER	(1<<7)

#define	UART1_RXD_MAX		1024
#define	UART1_TXD_MAX		UART1_RXD_MAX

/* Exported functions ------------------------------------------------------- */
void	InitUartParam(void);
void	UardDmaFlow(void);
BOOLEAN	DMA_UartTxd(void);
BOOLEAN	DMA_UartRxd(void);

/* Exported valable -------------------------------------------------------- */

STM_USART_CtrolBlock	STM_USARTCB;	//���ƿ�
INT8U UartCommBuf[UART1_RXD_MAX];
#endif /* __USART_H */

/******************* (C) COPYRIGHT 2009 LISTEN *****END OF FILE****/
