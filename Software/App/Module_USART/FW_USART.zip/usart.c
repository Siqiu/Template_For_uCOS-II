/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                          (c) Copyright 2003-2013; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include "usart.h"
#include "stm32f10x_usart.h"

#define	TRUE	1



/* Extern marco --------------------------------------------------------------*/
/* Private macro ------------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Extern functions ----------------------------------------------------------*/
/* Extern variable -----------------------------------------------------------*/

/*********************************************************/
//DMA 2-UART3_TX, 3-UART3_RX, 4-UART1_TX, 5-UART1_RX, 6-UART2_RX, 7-UART2_TX 
BOOLEAN DMA_UartTxd(void)
{
   STM_USART_CtrolBlock	*uart=(STM_USART_CtrolBlock *)(&STM_USARTCB);
   
   Rs485S;
   
   uart->CommStatus |= TXD_ING;
   uart->CommStatus &= ~TXD_ENABLE;
   
   DMA1_Channel4->CCR &= ~1;
   RCC->AHBENR |= RCC_AHBPeriph_DMA1;        
   DMA1_Channel4->CMAR  = (INT32U)(&UartCommBuf);	    
   DMA1_Channel4->CPAR  = (INT32U)&(USART1->DR);		
   DMA1_Channel4->CNDTR = uart->TxdPackLength;                                        
   DMA1_Channel4->CCR   = DMA_M2M_Disable | DMA_Priority_Medium | DMA_MemoryDataSize_Byte | DMA_PeripheralDataSize_Byte |
      DMA_MemoryInc_Enable | DMA_PeripheralInc_Disable | DMA_Mode_Normal | DMA_DIR_PeripheralDST;
   
   USART1->CR3 |= USART_DMAReq_Tx;
   DMA1_Channel4->CCR  |= 1;	// enable DMA Channe 
   
   return (TRUE);
}
//*********************************************************
BOOLEAN DMA_UartRxd(void)
{
	INT32U sr, dr;
#ifdef OS_TICKS_PER_SEC	 	//���ʱ�ӽ�����������,˵��Ҫʹ��ucosII��.
	OS_ENTER_CRITICAL();
#endif
	STM_USART_CtrolBlock	*uart=(STM_USART_CtrolBlock *)(&STM_USARTCB);
	uart->CommStatus &= ~RXD_END;
	uart->CommStatus |= RXD_WAIT;
	uart->RxdByteCnt = 0;
	
	sr = USART1->SR;
	dr = USART1->DR;
	DMA1_Channel5->CCR &= ~1;
	RCC->AHBENR |= RCC_AHBPeriph_DMA1;           		
	DMA1_Channel5->CMAR  = (INT32U)(&UartCommBuf);    	//DMA�洢����ַ�Ĵ���
	DMA1_Channel5->CPAR  = (INT32U)&(USART1->DR);	 		//�������ݼĴ�������ַ
	DMA1_Channel5->CNDTR = UART1_RXD_MAX;               //�������������Ĵ���      
	DMA1_Channel5->CCR   = DMA_M2M_Disable | DMA_Priority_High | DMA_MemoryDataSize_Byte | DMA_PeripheralDataSize_Byte |
		DMA_MemoryInc_Enable | DMA_PeripheralInc_Disable | DMA_Mode_Normal | DMA_DIR_PeripheralSRC;
	
	USART1->CR3 |= USART_DMAReq_Rx;					    //����DMA����ʹ��
	DMA1_Channel5->CCR  |= 1;	// enable DMA Channe	
	
	Rs485R;
	
	return (TRUE);
#ifdef OS_TICKS_PER_SEC	 	//���ʱ�ӽ�����������,˵��Ҫʹ��ucosII��.
	OS_EXIT_CRITICAL();
#endif
}
//*********************************************************
void USART1_IRQHandler(void)
{
   INT32U  dr, sr, Flag;
#ifdef OS_TICKS_PER_SEC	 	//���ʱ�ӽ�����������,˵��Ҫʹ��ucosII��.
	OS_ENTER_CRITICAL();
#endif
   dr = USART1->DR;
   sr = USART1->SR;
   if (sr & USART_FLAG_IDLE)
   {
      USART1->SR &= (~USART_FLAG_IDLE);
      STM_USARTCB.CommStatus |= RXD_END;
      STM_USARTCB.RxdByteCnt = UART1_RXD_MAX - DMA1_Channel5->CNDTR;
   }
   
   if (sr & USART_FLAG_TC)
   {
      USART1->SR &= (~USART_FLAG_TC);
      STM_USARTCB.CommStatus |= TXD_ENABLE;
	  DMA_UartRxd();
   }
#ifdef OS_TICKS_PER_SEC	 	//���ʱ�ӽ�����������,˵��Ҫʹ��ucosII��.
   OS_EXIT_CRITICAL();
#endif
}
/*********************************************************/
void InitUartParam(void)
{
   STM_USARTCB.CommStatus	= (TXD_ENABLE | RXD_WAIT);
   STM_USARTCB.RxdByteCnt	= 0;
   STM_USARTCB.TxdPackLength	= 0;  
   DMA_UartRxd();
}
/*********************************************************/
void UardDmaFlow(void)
{
	INT16U len;
	
	if (STM_USARTCB.CommStatus & RXD_END)
	{
		STM_USARTCB.CommStatus &= ~RXD_END;
		len =Modbus_Client(UartCommBuf, STM_USARTCB.RxdByteCnt);//������ʾ�����ò���
		if (len!=0)
		{
			STM_USARTCB.TxdPackLength = len;
			DMA_UartTxd();//modbus����
			//if(*(UartCommBuf+1) == WRITE_SINGLE_REG)//дmodbus����			
			//	Set_Para(gPDataBuffer);//��ʾ��ǰ����״̬			 
			//DMA_UartRxd();
			return;	 //�������¿����գ�485����������ٿ�����
		}		
		// CheckPack(UartCommBuf);			//У��Э��������,���������򲻿���ChangeState����
		// DMA_UartRxd();	//���¿�������	
		else
		{	 
			len = DealUpdataCode_Data(UartCommBuf, UartCommBuf, STM_USARTCB.RxdByteCnt);
			if (len)	//������
			{
				STM_USARTCB.TxdPackLength = len;
				DMA_UartTxd();
			}
			else
			{
				CheckPack(UartCommBuf);			//У��Э��������,���������򲻿���ChangeState����
				DMA_UartRxd();	//���¿�������	
			}
		}		
	}
}
/******************* (C) COPYRIGHT 2013 LISTEN *****END OF FILE****/
